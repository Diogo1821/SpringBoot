package br.senac.tads.dsw.dados_pessoais.seguranca;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

// Implementa UserDetailsService - interface que o  Spring Security usa para carregar um usuário
// pelo username durante o processo de autenticação.
// O método loadUserByUsername() é chamado automaticamente pelo AuthenticationManager.
@Service
public class UsuarioSistemaService implements UserDetailsService {
    
    private final Map<String, UserDetails> usuarios;

    // O PasswordEncoder é injetado pelo Spring Security para codificar as senhas na inicialização do serviço.
    // Neste momento usamos NoOpPasswordEncoder (texto puro). Será trocado por BCrypt na Etapa 7.
    public UsuarioSistemaService(PasswordEncoder passwordEncoder) {
        usuarios = new HashMap<>();

        // admin - acesso total: ROLE_ADMIN, ROLE_GERENTE e ROLE_USER
        this.usuarios.put("admin", new UsuarioSistema(
            "admin",
            passwordEncoder.encode("Abcd%12345"), // senha codificada
            List.of(
                new SimpleGrantedAuthority("ROLE_ADMIN"),
                new SimpleGrantedAuthority("ROLE_GERENTE"),
                new SimpleGrantedAuthority("ROLE_USER")
            )
        ));

        // user1 - acesso intermediário: ROLE_GERENTE e ROLE_USER
        this.usuarios.put("user1", new UsuarioSistema(
            "user1",
            passwordEncoder.encode("Abcd%12345"), // senha codificada
            List.of(
                new SimpleGrantedAuthority("ROLE_GERENTE"),
                new SimpleGrantedAuthority("ROLE_USER")
            )
        ));

        // user2 - acesso básico: somente: ROLE_USER
        this.usuarios.put("user2", new UsuarioSistema(
            "user2",
            passwordEncoder.encode("Abcd%12345"), // senha codificada
            List.of(
                new SimpleGrantedAuthority("ROLE_USER")
            )
        ));
    }

    // Chamado pelo Spring Security quando precisa verificar as credenciais de um usuário.
    // Em um sistema real, este método consultaria o banco de dados.
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserDetails usuario = usuarios.get(username);
        if (usuario == null) {
            throw new UsernameNotFoundException("Usuário não encontrado: " + username);
        }
        return usuario;
    }
}