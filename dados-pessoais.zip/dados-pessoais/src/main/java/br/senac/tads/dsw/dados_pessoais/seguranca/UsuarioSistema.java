package br.senac.tads.dsw.dados_pessoais.seguranca;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

// Representa um usuário no contexto do Spring Security.
// User Details é a interface padrão que o framework usa para carregar e inspecionar usuários;
// Ao implementá-la, esta classe "fala a língua" do Spring Security.
public class UsuarioSistema implements UserDetails {
    
    private static final long serialVersionUID = 1L;

    private final String username;
    private final String password; // Senha já codificada pelo PasswordEncoder do Spring Security
    private List<GrantedAuthority> authorities; // Permissão do usuário (ex.: ROLE_ADMIN, ROLE_USER, etc.)

    public UsuarioSistema(String username, String password, List<GrantedAuthority> authorities) {
        this.username = username;
        this.password = password;
        this.authorities = authorities;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public String getPassword() {
        return password;
    }

    //getAuthorities() retorna a lista de permissões (roles) do usuário.
    // GrantedAuthority é uma interface; SimpleGrantedAuthority  é a implementação padrão.
    
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    // Os quatro métodos abaixo controlam o estado da conta.
    // Retornam true por simplicidade - em produção você implementaria lógica de bloqueio,
    // expiração de senha, etc., consultando um banco de dados.
    @Override
    public boolean isAccountNonExpired() {
        return true; // conta nunca expira
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // conta nunca é bloqueada
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // credenciais nunca expiram
    }

    @Override
    public boolean isEnabled() {
        return true; // conta sempre habilitada
    }
}
